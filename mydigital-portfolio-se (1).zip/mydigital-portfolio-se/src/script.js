// -------------------- Navigation Scroll --------------------
document.querySelectorAll('nav ul li a').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const targetId = this.getAttribute('href').substring(1);
        const targetSection = document.getElementById(targetId);
        if(targetSection) {
            window.scrollTo({
                top: targetSection.offsetTop - 70,
                behavior: 'smooth'
            });
        }
    });
});

// -------------------- Image Upload Preview --------------------
const imageInput = document.getElementById('profileImage');
const imagePreview = document.getElementById('imagePreview');

if(imageInput && imagePreview){
    imageInput.addEventListener('change', function() {
        const file = this.files[0];
        if(file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                imagePreview.src = e.target.result;
            }
            reader.readAsDataURL(file);
        }
    });
}

// -------------------- Project Cards Dynamically --------------------
const projectsData = [
    {
        title: 'Portfolio Website',
        description: 'A personal portfolio website built with HTML, CSS, and JavaScript.',
        img: 'project1.jpg'
    },
    {
        title: 'Todo App',
        description: 'A simple todo list application using JavaScript.',
        img: 'project2.jpg'
    },
    {
        title: 'Weather App',
        description: 'Shows current weather of any city using API.',
        img: 'project3.jpg'
    }
];

const projectContainer = document.querySelector('.project-container');
if(projectContainer){
    projectsData.forEach(project => {
        const card = document.createElement('div');
        card.classList.add('project-card');

        card.innerHTML = `
            <img src="${project.img}" alt="${project.title}">
            <div class="project-info">
                <h3>${project.title}</h3>
                <p>${project.description}</p>
            </div>
        `;
        projectContainer.appendChild(card);
    });
}

// -------------------- Skills Dynamically --------------------
const skills = ['JavaScript', 'HTML', 'CSS', 'React', 'Node.js', 'Python'];
const skillsContainer = document.querySelector('.skills-container');

if(skillsContainer){
    skills.forEach(skill => {
        const skillElem = document.createElement('div');
        skillElem.classList.add('skill');
        skillElem.textContent = skill;
        skillsContainer.appendChild(skillElem);
    });
}

// -------------------- Contact Form Submission --------------------
const contactForm = document.getElementById('contactForm');
if(contactForm){
    contactForm.addEventListener('submit', function(e){
        e.preventDefault();
        alert('Thank you! Your message has been submitted.');
        contactForm.reset();
    });
}

// -------------------- Mobile Menu Toggle --------------------
const menuToggle = document.querySelector('.menu-toggle');
const navUl = document.querySelector('nav ul');

if(menuToggle && navUl){
    menuToggle.addEventListener('click', () => {
        navUl.classList.toggle('active');
    });
}